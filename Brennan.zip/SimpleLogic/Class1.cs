﻿namespace SimpleLogic;

public class Class1
{

}
