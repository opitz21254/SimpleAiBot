namespace SimpleTests;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {
        //Given

        //When

        //Then

    }
}